# Job Board Auto

Android accessibility automation prototype based on the supplied screenshots.

## What it does
- Configurable minimum £ threshold (default £50).
- Reads visible `£` values from the accessibility node tree.
- Attempts to scroll the job board continuously with an ~80 ms control loop.
- When a visible value reaches the threshold, it stops scrolling and attempts to activate the upper-right accept/check control.
- Speaks "İş kabul edildi" using Android Text-to-Speech after a successful accessibility click.
- Start/Stop controls are provided in the app.

## Important implementation detail
The preferred path is the accessibility tree, not OCR, because it is much faster when the target app exposes its text and buttons to AccessibilityService. The project includes no anti-bot bypassing.

If the target app does not expose the price or the check button through accessibility, a device-specific OCR/screenshot fallback would be required and must be tested on the actual phone/app version.

## Build
Open the folder in Android Studio and build the debug APK. The build environment used for this response does not contain the Android SDK/Gradle Android plugin, so an APK binary could not be compiled here.
